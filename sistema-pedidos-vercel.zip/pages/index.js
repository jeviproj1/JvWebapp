
export default function Home() {
  return <h1>Sistema de Pedidos - Deploy Inicial</h1>;
}
