
import React from 'react';
import ReactDOM from 'react-dom/client';
import SistemaDePedidos from './SistemaDePedidos';

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <SistemaDePedidos />
  </React.StrictMode>
);
